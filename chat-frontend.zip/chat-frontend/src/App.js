import React, { useState, useEffect } from "react";
import io from "socket.io-client";
import "./App.css";

const socket = io("http://localhost:3001");

function App() {
  const [message, setMessage] = useState("");
  const [chat, setChat] = useState([]);

  const sendMessage = () => {
    if (message.trim() === "") return;
    socket.emit("send_message", { message });
    setMessage("");
  };

  useEffect(() => {
    socket.on("receive_message", (data) => {
      setChat((prev) => [...prev, data.message]);
    });
  }, []);

  return (
    <div className="chat-container">
      <h2>💬 Live Chat</h2>
      <div className="chat-box">
        {chat.map((msg, idx) => (
          <div key={idx} className="chat-bubble">{msg}</div>
        ))}
      </div>
      <input
        type="text"
        value={message}
        placeholder="Type something..."
        onChange={(e) => setMessage(e.target.value)}
        onKeyDown={(e) => e.key === "Enter" && sendMessage()}
      />
      <button onClick={sendMessage}>Send</button>
    </div>
  );
}

export default App;
